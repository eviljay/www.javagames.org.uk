*************
Concentration
*************
by John Morris

- To install using the provided
web page

1. Place "Concentration.class" in
the same folder as "concentration.htm"
and open "concentration.htm" with your
web browser.

- To install on your web page

1. Place the following html into
the html of the page on which you
want Concentration to appear:

<applet width="430" height="470" code="Concentration.class" archive="Concentration.jar">
</applet>

2. Place "Concentration.class" into
the same folder as you web page and
open you web page with your browser.

Visit Java Playground again for
more applets.

John Morris