// Animated helpBox
// Bavo Bruylandt


import java.awt.*; import java.awt.event.*;import java.net.*;import java.applet.*;

class Helpbox extends Frame
 	           implements WindowListener, ActionListener {

  
String solutionstring, btlabel;
boolean menuhelp;
Button ok, visit;
Iqapplet iq;

  public Helpbox(String btlabel1,Iqapplet iq,String s,String solutionstring1,boolean menuhelp1) {
  	super(s);
  	this.iq = iq;
  	solutionstring = solutionstring1;
  	btlabel = btlabel1;
  	menuhelp = menuhelp1;
  	setSize(400,400);
  	setLocation(250,50);
  	Color bg = new Color(0,0,122);
    setBackground (bg);
    addWindowListener (this);
    ok = new Button("Thanx for the help...");

    ok.addActionListener(this);
    setLayout(null);
 		ok.setBounds(40,300,140,40);
		add(ok);
    visit = new Button("Visit Homemadejava");

    visit.addActionListener(this);
 		visit.setBounds(220,300,140,40);
		add(visit);

    setVisible(true);
    }
    
	public void paint(Graphics g) {
	
			Font f = new Font("Verdana", Font.BOLD, 20);
			g.setFont(f);
			g.setColor(Color.white);
			g.drawString("Help",180,50);
			Font p = new Font("Verdana", Font.PLAIN, 15);
			g.setFont(p);
			g.setColor(Color.white);
			if (menuhelp) {
			g.drawString("Answer each question and press next.",60,100);
			g.drawString("If you dont know the answer you can",60,130);
			g.drawString("click next and later return to it by ",60,160);
			g.drawString("pressing previous. If you are done",60,190);
			g.drawString("Click stop to see the results.",60,220);
			g.drawString("Http://www.homemadejava.com",60,250);
	}
	else {
		if (btlabel.equals("Solution")) {
		g.drawString("The answer to this question is:",60,100);
			g.drawString(solutionstring,60,130);
			g.drawString("This will declare the test invalid",60,160);
		}
		else {
			g.drawString("This is a creation of Javadesign",60,100);
			g.drawString("Our work can be downloaded at:",60,130);
			g.drawString("Http://www.homemadejava.com",60,160);
			g.drawString("Click the button to visit us.",60,190);
			g.drawString("Thanks for using our software!",60,220);

		}
	}}
	        	
 

	         	
  public void windowClosed (WindowEvent evt) {}
  public void windowDeiconified (WindowEvent evt) {}
  public void windowIconified (WindowEvent evt) {}
  public void windowActivated (WindowEvent evt) {}
  public void windowDeactivated (WindowEvent evt) {}
  public void windowOpened (WindowEvent evt) {}
  public void windowClosing (WindowEvent evt) {
    this.dispose();
  }
	 public void actionPerformed(ActionEvent evt) {
	 	if (evt.getSource() == ok) {
	 		this.dispose();
	 	}
	 	else {
	 		try {
	 			iq.getAppletContext().showDocument(new URL("Http://www.homemadejava.com"),"newWindow");
	 		}
	 		catch (MalformedURLException mfurl) {
	 		}
	 }         	
}}