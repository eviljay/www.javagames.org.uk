// By DaHazard (Bavo Bruylandt)
// Calls the frame
// This source code is property of Javadesign.
// You can use it for study or idea's, but it's
// illegal to put your name under this source
// or to make yourself a license.


import java.applet.*;
import java.awt.event.*;
import java.util.EventListener;
import java.awt.*;
import java.net.*;
import java.io.*;


public class Iqapplet extends Applet implements ActionListener {
	Button ok1 = new Button("Start Iqquiz");
	Iqquiz iq;
	int autoload;
	int regnum;
	String companyname = "";
	String registered = "";
	boolean reg = false;
	private InputStream input;
	

		
	public void init () {
		reg = registration();

		setLayout(null);
  	autoload =	(getParameter("autoload") == null)? 0 : Integer.parseInt(getParameter("autoload"));
		ok1.addActionListener(this);
		ok1.requestFocus();
		Dimension dim = getSize();
		ok1.setBounds(1,1,dim.width-2,dim.height-2);
		add(ok1);

	}
	
	public void start() {
				if (autoload == 1) {
			iq = new Iqquiz(this);
			iq.setVisible(true);
		}	
}
	
	public void actionPerformed (ActionEvent act) {
				if (act.getActionCommand()=="Start Iqquiz") {
			if (iq == null) {
			iq = new Iqquiz(this);
			iq.setVisible(true);
			}
			

		}
	}
	
	public void paint (Graphics g) {}
	
		public boolean registration() {
		try {
			input = new URL(getDocumentBase(),"License.txt").openStream ();
		}
		catch (Exception e) {

			System.out.println("Corrupted License file or file is missing");
			System.out.println("or it runs in NS locally.");

			return false;

		}
		try {
			char kar = 'a';
			while (kar != '\n' && kar > 0) {
				kar = (char) input.read ();
				if (kar != '\n' && kar != '\r') companyname += kar;
			}
		}
		catch (Exception re) {
			System.out.println(re);
			return false;
		}
		//System.out.println(companyname);
	
	try {
			char kar1 = 'a';
			while (kar1 != '\n' && kar1 > 0 && kar1 != '\r') {
				kar1 = (char) input.read ();
				if (kar1 != '\n'  && kar1 != '\r') registered+= kar1;
			}
	}
	catch (Exception re) {
		System.out.println(re);
		return false;

		
	}
	//System.out.println(registered);
	for(int b = 0;b<companyname.length();b++) {
	regnum+=companyname.charAt(b)+0;
	}
	//System.out.println(regnum);
	try {
	if (Integer.parseInt(registered) == regnum) {
		System.out.println("Registered to " + companyname);
		reg = true;
	}
	else { 
		System.out.println("Unregistered Version");
		reg = false;
	}
	}
	catch (Exception nfe) {
		System.out.println("Registration number is corrupted");
		System.out.println("or it runs in NS locally.");

		return false;
	}
	return reg;
	
}

}