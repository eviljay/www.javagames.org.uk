import java.applet.Applet;

import java.awt.*;
import java.awt.image.*;

// REMEMBER: the play area of worm is 480 wide X 330 high



public class werm extends Applet implements Runnable {


Image playarea;

Image brick;

int imgw, imgh;
PixelGrabber grabber;




int ns = 100;// number of stars...max 1000 
int width = 480; // applet dimentions
int height = 380; 
int[] x = new int [1000]; 
int[] y = new int [1000]; 
int[] z = new int [1000]; 
int[] sp = new int[1000];
int lens, scrx, scry, dist;
int widthmiddle;
int heightmiddle;
int fontsize;
int pixel2, pixel3;
 int linex = 45;// used to scan the opposite side of worm
int liney = 25;

int[] universe={11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,	
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

				12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,	
				   0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

			
				13,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,	
				   0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

				14,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,1,1,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,	
				   0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,1,1,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,


				15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,1,0,0,0,0,
				   0,0,0,1,1,1,1,0,0,1,0,0,1,0,0,1,0,0,0,0,	
				   0,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,1,1,1,1,0,0,1,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,
				   0,0,1,1,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,


				16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,	
				   0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,1,0,0,0,0,1,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,1,1,1,0,0,1,1,1,0,0,1,0,0,0,0,
				   0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,



		    	17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	
				   0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

			    18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,	
				   0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

                19,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,	
				   0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

                20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	//  25 square 19*15
          		   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,	
				   0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
				   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


int keyz;
int[] pixels; 
int grab;	
int speed = 5;    
int point = 10;
int wormsize = 300;
int grow =200;
int[][] worm = new int[2][9000]; /* the arry for the worm */ 
//int rgbRed = 200; // used to change worm's color
//int rgbGreen = 10;
//int rgbBlue = 50;
boolean playOn = false;  
public int horizontal = 70;
public int vertical = 70 ;
int number;
int numberY, numberX; 
int belowRow = 0; // used for shifting worm
int direction;
int lastdirection = 1 ;
int score;
int level = 1;
boolean initplayarea = false;
boolean wormontop = false;
boolean wormdied = false;
boolean set = false;
boolean star = true;
boolean loaded = false;
int lives = 3;
int returned;
int horizcolor = 1;
int vertcolor =1;
int green = 0;int green2; int green3;
int dumb;
int sideHeadx, sideHeady;
Image workspace; // double buffer for the display, to prevent flicker
Graphics offscreen;
Thread runner; // main thread, starts the run() method.

   /**

     * Initializes the applet.  You never need to call this directly; it is

     * called automatically by the system once the applet is created.

     */

    public void init() {
		// loard in the images
		//repaint();
	  
		if (loaded == false) { 
		showStatus("Applet succesfully loaded! Please wait...loading applets images...this may take a while..");	    
		MediaTracker t = new MediaTracker (this);
		repaint();
	    playarea = getImage(getCodeBase(), "playarea.jpg");

		  	
			brick = getImage(getCodeBase(), "brick.jpg");

		t.addImage (playarea, 1);
		 
		 //(getGraphics()).drawString("Loading 1/7....please wait",30,30);
		

		t.addImage (brick, 9);
	

		try t.waitForID(1);
		catch (InterruptedException ie) return;
	
		showStatus("1 of 2 loaded...");
	
		try t.waitForID(9);
		catch (InterruptedException ie) return;


		showStatus("2 of 2 loaded...now pre-calculating 3d starfield..");
		loaded = true;
		} // end if loaded
		  
	initplayarea = false;
    workspace = createImage(size().width, size().height); // our off-screen buffer
    offscreen = workspace.getGraphics();

	lens = 256;	
    
	direction = lastdirection;
    number = 1;
    Font normalFont = new Font("TimesRoman", Font.BOLD, 9);
    

	imgw = 480; // workspace.getWidth(this);
	imgh = 380; //workspace.getHeight(this);
	pixels = new int[imgw*imgh];
	
    
    green = 0;	
    
    widthmiddle = width /2;
    heightmiddle = height /2;	
	makerandom();
	
	}

/**/////////////////////////////////////////////////////////////////////////////////////
    /**

     * Called to start the applet.  You never need to call this directly; it

     * is called when the applet's document is visited.

     */

public void start() { 

	if (runner == null) {
	    runner = new Thread(this); 
        runner.start();
	    }	
    }

///////////////////////////////////////////////////////////////////////////////////////




public void makerandom() {	/** makes random stars  */


	int dummy = 0;
	
	while (dummy < ns) { 
	

		x[dummy] = (int) (Math.random() * width) - widthmiddle;
		y[dummy] = (int) (Math.random() * height) - heightmiddle;
		z[dummy] = (int) (Math.random() * 750) -500;	 
		sp[dummy] = (int) (Math.random() * 6) + 1;
		dummy++;
		showStatus("Getting random values...:"+dummy);

	}

}


/////////////////////////////////////////////////////////////////////////////////////////// 
 
public void drawlevel() {
	 int marker;
	 int cell =0;
	 int sx = 0;
	 int sy = 0;
	 int i =0;

	 marker = 10;
	 
	 while (marker != level+10) {
		 marker = universe[i];
		 i++;
		 
	 }


	 offscreen.drawImage(playarea, 0,0, this);
	
		 for (sy =0; sy <= 380; sy+=25) {
	 	  for (sx =0; sx <= 480; sx+=25) {

	 
	
		
		     cell = universe[i];
	 i++;
	 if (cell == 1)
	 offscreen.drawImage(brick, sx,sy, this);
	 
	 
		 }//end for x
		
	 }//end for y


	
 }

///////////////////////////////////////////////////////////////////////////////////////	   
	   public void scanworm() {// scans if worm is on top of itself.
  

  

showStatus(""+grow);

	for (int row = 1;row != grow; row++) {
		
		//
	


		if (direction == 1) { //down?
			linex = worm[0][row];
			liney = worm[1][row];

		}
	  
		if (direction == 2) { //up?
			linex = worm[0][row];
			liney = worm[1][row] + 12; 
	

		
		}
	   
		if (direction == 3) { //right
			linex = worm[0][row];
			liney = worm[1][row]; 
		
		}
		 
		if (direction == 4) { //left
			linex = worm[0][row] + 12;
			liney = worm[1][row]; 
		
		}


if  ((linex == horizcolor) && (liney == vertcolor)) {
					 wormontop = true;
	     	}//if

  

if ( (worm[0][row] == horizcolor) && (worm[1][row] == vertcolor)){

					 wormontop = true;
			}//if

  
		}//for

	
   }
/////////////////////////////////////////////////////////////////////////////////////////

  public void shiftworm() { // shifts all x,y values in worm arry down

 int xTemp, yTemp;
 for (int rowShift = grow - 1; rowShift != 0; rowShift--) {
 int aboveRow = rowShift - 1;    
 xTemp = worm[0][aboveRow]; // gets value from above
 yTemp = worm[1][aboveRow];
 worm[0][rowShift] = xTemp; // puts the value below
 worm[1][rowShift] = yTemp;

  }} // end shiftworm   

/////////////////////////////////////////////////////////////////////////////////////////

public void randomplot() { /** selects a random position, and tests if it is valid 
							   to plot the number there */


//green = 100;
boolean freespace = false;
int bottomcorner;
int rightcorner;
int leftcorner;

 do {

numberX = (int) (Math.random() * 430) + 20;
numberY = (int) (Math.random() * 280) + 70;
	
  
    int npixel = pixels[numberY*imgw + numberX]; // y*imgw + x
	int bpixel = pixels[(numberY+10)*imgw + numberX];
	int rpixel = pixels[numberY*imgw + (numberX+15)];
	int lpixel = pixels[numberY*imgw + (numberX-1)];
	int corner = pixels[(numberY+15)*imgw + (numberX+10)];
	//int alpha = (npixel >> 24) &0xff;
	int red = (npixel >> 16) & 0xff;
	int ngreen = (npixel >> 8) & 0xff;
	int bgreen = (bpixel >> 8) & 0xff;
	int rgreen = (rpixel >> 8) & 0xff;
	int lgreen = (lpixel >> 8) & 0xff;
	int cgreen = (corner >> 8) & 0xff;

	if (cgreen == 0) {
	if (ngreen == 0) {  
	if (bgreen == 0) { 
	if (rgreen == 0) { 
	if (lgreen == 0) { freespace = true;
	
	}}}}}

	int blue = (npixel) & 0xff;
	if (ngreen > 0) { freespace = false;}
	showStatus("free green"+ngreen+"blue:"+blue+"red"+red);

 } while(freespace == false);


}// end random plot

////////////////////////////////////////////////////////////////////////////////////////

public void clearworm() {// clears the worm of co-ordinates, after it has died.
  
	for (int row = 0;row != wormsize; row++) {
					worm[0][row] = 0;
					worm[1][row] = 0;
				
	}
}// end clearworm

////////////////////////////////////////////////////////////////////////////////////
public void collidedetection() { // detects if worm collided with a number
int numberoffsetY = numberY + 5;
int numberoffsetX = numberX + 7;
int wormoffsetX = worm[0][0] + 2;
int wormoffsetY = worm[1][0] + 5;

if (wormoffsetY > numberY) {
	if (worm[1][0] < numberoffsetY) {
		if (wormoffsetX > numberX) {
			if (worm[0][0] < numberoffsetX) {

				number++;
				//;
				score = score + 200;
				
				wormsize = wormsize + 50;
			
				if (number != 10) {
				randomplot();
				}
				
			}
		 }
	}
} } // end of collide detection
////////////////////////////////////////////////////////////////////////////////////////////		  

public void colordetection() {

     if (direction == 1)	{  // down
	
	horizcolor = 5+horizontal; vertcolor = 14+vertical;
	pixel2 = pixels[(vertcolor-4)*imgw + horizcolor-7]; // y*imgw + x
	pixel3 = pixels[(vertcolor-4)*imgw + horizcolor+7];
	 green2 = (pixel2 >> 8) & 0xff;
	green3 = (pixel3 >> 8) & 0xff;

	 }
	if (direction == 2)	{	// up
	
	horizcolor = 5+horizontal;
	vertcolor = -1+vertical;
	 pixel2 = pixels[(vertcolor+4)*imgw + horizcolor-7]; // y*imgw + x
	pixel3 = pixels[(vertcolor+4)*imgw + horizcolor+7]; // y*imgw + x
	green2 = (pixel2 >> 8) & 0xff;
	green3 = (pixel3 >> 8) & 0xff;

	}
	if (direction == 3)	{	// right

	horizcolor = 14+horizontal; vertcolor = 7+vertical;
	
	pixel2 = pixels[((vertcolor-4)*imgw) + horizcolor-4]; // y*imgw + x
	pixel3 = pixels[((vertcolor+4)*imgw) + horizcolor-4];
	green2 = (pixel2 >> 8) & 0xff;
	green3 = (pixel3 >> 8) & 0xff;
	  
	}
	if (direction == 4)	{
	vertcolor = 7+vertical; horizcolor = -1+horizontal;	 // left
	//*
	pixel2 = pixels[(vertcolor-4)*imgw + horizcolor+4]; // y*imgw + x
	pixel3 = pixels[(vertcolor+4)*imgw + horizcolor+4];
	green2 = (pixel2 >> 8) & 0xff;
	green3 = (pixel3 >> 8) & 0xff;
	 // */
	}

	int pixel = pixels[vertcolor*imgw + horizcolor]; // y*imgw + x
	
	

	
	//}	}

	//int alpha = (pixel >> 24) &0xff;
	//int red = (pixel >> 16) & 0xff;
	green = (pixel >> 8) & 0xff;
	
	//int blue = (pixel) & 0xff;


}

/////////////////////////////////////////////////////////////////////////////////////////				  	  	  
public void run() { // called automaticaly after init()

	
   	    

	while (true) {
	
	if (playOn == false) { showStatus("click on applet and hit F2 to START!");}

	while (playOn == false) {
		//speed = 1;
		showStatus("click on applet and hit F2 to START!");
		try {Thread.currentThread().sleep(10);} //pauses applet 
	    catch (InterruptedException e) {}
		
		
Font dotFont = new Font("TimesRoman", Font.PLAIN, 10);


offscreen.setColor(Color.black);
offscreen.fillRect(0,0,width,height);
offscreen.setColor(Color.white);
offscreen.setFont(dotFont);


	for (int d = 1; d < ns; d++) {

		z[d] +=sp[d];

		if (z[d] > 255)  
			z[d] = -500;	

		dist = 256 - z[d];
		


		scrx = ((lens * x[d]) /dist) + widthmiddle;
		if (scrx < width){// just a little optimization....
		scry = heightmiddle - ((lens*y[d]) / dist);
		if (scry < height) {
			
			
		offscreen.drawLine(scrx,scry,scrx,scry);
		
		}
		}
		
	 }// end for
offscreen.setColor(Color.yellow);

 
Font currentFont = new Font("TimesRoman", Font.PLAIN, fontsize);
offscreen.setFont(currentFont);
if (fontsize < 80) {
fontsize++;

}

offscreen.drawString("WERMZ",90,heightmiddle);
offscreen.setFont(dotFont);
offscreen.drawString("version 2.6",0,10);
	repaint();

	}



	if ((playOn == true) && (loaded == true)){
	  
	scanworm();
	
		   
	
	try {Thread.currentThread().sleep(1);} //pauses applet 
	catch (InterruptedException e) {}		 

			 
	if (initplayarea == false) {
		initplayarea = true;
		
		offscreen.setColor(Color.black);
		drawlevel();
		try {Thread.currentThread().sleep(500);} //pauses applet 
	catch (InterruptedException e) {}
		drawlevel();// again because of JIT compilers...
			PixelGrabber grabber = new PixelGrabber(workspace, 0, 0, imgw, imgh,pixels, 0, imgw);

		 try {
			grabber.grabPixels();
	}	catch (InterruptedException exception) {
		offscreen.drawString("Error getting pixels",200,100);
	}

	randomplot(); // the first number is chosen
	
	}


		
	offscreen.setColor(Color.black);

	if ( (worm[0][wormsize] !=0) && (worm[1][wormsize] !=0)) {
		
		offscreen.fillRect(worm[0][wormsize],worm[1][wormsize], 16, 13);

	
	}
	
	
	if (grow <= wormsize) {
	grow++;
	}

	
	offscreen.setColor(Color.blue);
	offscreen.fillOval(horizontal , vertical, 13,12 );
    

	offscreen.setColor(Color.cyan);
	offscreen.drawString("" + number, numberX + 5, numberY + 10);

	lastdirection = direction;

shiftworm();       
score--; // score goes downn...
collidedetection();

if (number > 10 ) { // THE MAIN LEVEL CHANGE HAPPENS HERE!!!
	number = 1;
	
	clearworm();
	wormsize = 300;
	grow = 1;
	/////////////
	horizontal = 70;
	vertical = 70;
	///////////////
	score = score + 1000;
	level++;
	set = false;

	


	if (level > 7) { playOn = false;
					 //grab();
					 level = 1;
	}
	try {Thread.currentThread().sleep(1000);} //pauses applet 
	    catch (InterruptedException e) {}
	randomplot();
	initplayarea = false;


	}// end level change	



if (grow < 20) {green = 1;}

colordetection();
		

if ((wormontop == true)  || (green > 45) || (green2 > 45) || (green3 > 45)) {
		green2 = 0;
		green3 = 0;
		grow = 1;
        wormdied = true;
		showStatus("Green is now:" +green);
		for (int row = 0;row != wormsize; row++) {
		worm[0][row] = 0;
	    worm[1][row] = 0;			
		}
		direction = 3; // right
		worm[0][0] = 70;
	    worm[1][0] = 70;
	
		horizontal = 70;
		vertical = 70;
		wormsize = 300;
		wormontop = false;
	}


if (direction == 1) {     // going down
	vertical = vertical + 1;   
if (vertical > 355) {     
	vertical = vertical - 290; // warp effect
} 											  
worm[0][0] = horizontal;  
  worm[1][0] = vertical;
  lastdirection = 1;
   }
   if (direction == 2) {     // going up!
    vertical = vertical - 1; 
if (vertical < 65) {
 vertical = vertical + 290; // warp effect
}  
  worm[0][0] = horizontal;
    worm[1][0] = vertical; 
  lastdirection = 2;    
 }    
   if (direction == 3) { 
      horizontal = horizontal + 1; // going right!
if (horizontal > 455) {
horizontal = horizontal - 440; // warp effect
}   
 worm[0][0] = horizontal;
   worm[1][0] = vertical; 
   lastdirection = 3;
 }  
if (direction == 4) {     
   horizontal = horizontal - 1; // going left! 
if (horizontal < 13) {
horizontal = horizontal + 440; // warp effect
} 
 worm[0][0] = horizontal; 
   worm[1][0] = vertical; 
   lastdirection = 4;    } 
  lastdirection = direction; 
    
    
    


repaint();

}// if playon == true

 } // end of while     
}	       /* end of run */

///////////////////////////////////////////////////////////////////////////////////////////

public void stop() {      
if (runner != null) 	
runner.stop();
	runner = null;    

}
/////////////////////////////////////////////////////////////////////////////////

 public void paint(Graphics screen) { // PAINTING THE SCREEN!

	
	  
		
	
		if (wormdied == true) {
		
		screen.setColor(Color.yellow);
		Font dieFont = new Font("TimesRoman", Font.PLAIN, 20);
		screen.setFont(dieFont);
		screen.drawString("werm died",200,250);
		lives--;
		playOn = false;

		try {Thread.currentThread().sleep(1000);} //pauses applet 
			catch (InterruptedException e) {}
	
		initplayarea = false;
		wormdied = false;
		

	}
	


	
     // } // end of if (playOn)  
     
     }// end paint
 
////////////////////////////////////////////////////////////////////////////////////////////
public boolean keyDown(Event e, int key) {
	
	
	

	keyz = key;
	switch (key) {	
case 1005:{
   if (lastdirection == 2) {
    direction = lastdirection;
    }
    else {	
   direction = 1; // A:down
   }
    }			   
break;		
   case 1004:
   if (lastdirection == 1) {
   direction = lastdirection;
   }
   else {
  direction = 2; // D:up
  }
   break;
	case 1007:{
 if (lastdirection == 4) {
 }
 else {
  direction = 3; // K:right
  }		
 }
 break;
case 1006:
if (lastdirection == 3) {
}
else {	
 direction = 4; // M:left
 } 
break;
case 1012: {  // F5 stop
playOn = false;
level = 1;
initplayarea = false;	 
 	break;
	}
case 1009: { // F2
playOn = true;
star = false;
level = 1;
initplayarea = false;
	init(); // initialise the play area

}
  		default:{
direction = lastdirection;

break;	
}
}
  	return(false);

	}
////////////////////////////////////////////////////////////////////////////////////
public void destroy() {

    }

///////////////////////////////////////////////////////////////////////////////////
public void update(Graphics screen){

	screen.drawImage(workspace, 0,0, this);

   paint(screen);   
 }
  
} // the end